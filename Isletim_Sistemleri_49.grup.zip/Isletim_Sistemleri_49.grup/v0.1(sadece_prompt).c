#include <stdio.h>
#include <string.h>
#include <stdlib.h>


int main()
{
	char satir[80];
	char konum[100];
	char * parametreler[10][80];

	//prompt gibi davranmasi icin sonsuz dongu 
	while(1)
	{
		//komutların ve parametrelerin tutulacagi dizi
		

		getcwd(konum,100);
		printf("%s/: sau > ",konum);
		fgets(satir,100,stdin);



			


	}


}